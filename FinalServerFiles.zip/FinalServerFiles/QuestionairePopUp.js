<script type="text/javascript">
    $(window).on('load', function() {
        $('#ModalEthics').modal('show');
    });
</script>
